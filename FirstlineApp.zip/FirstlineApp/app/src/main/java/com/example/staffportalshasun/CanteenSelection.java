package com.example.staffportalshasun;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import webservice.WebService;

import static android.content.ContentValues.TAG;

public class CanteenSelection extends AppCompatActivity {
    RecyclerView mRecyclerView;                           // Declaring RecyclerView
    RecyclerView.Adapter mAdapter;                        // Declaring Adapter For Recycler View
    RecyclerView.LayoutManager mLayoutManager;            // Declaring Layout Manager as a linear layout manager
    private TextView tvPageTitle, tvLastUpdated;
    private static String strParameters[];
    private static String ResultString = "";
    private long lngEmployeeId=0;

    private ArrayList<String> template_list = new ArrayList<String>(200);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canteen_selection);

        tvPageTitle = (TextView) findViewById(R.id.pageTitle);
        tvPageTitle.setText("Canteen Selection");
        final SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
        Button btnBack=(Button) findViewById(R.id.button_back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                //Recycler View Menu
                Intent intent = new Intent(CanteenSelection.this, HomeScreen.class);
                //Grid View Menu
                //Intent intent = new Intent(StudentAttendanceTemplate.this, HomePageGridViewLayout.class);
                startActivity(intent);
            }
        });
        StatusColor.SetStatusColor(getWindow(), ContextCompat.getColor(this, R.color.colorblue));

        WebService.METHOD_NAME = " getCanteenListJson";
        AsyncCallWS task = new AsyncCallWS();
        task.execute();

//        lngEmployeeId = loginsession.getLong("userid", 1);
//        strParameters = new String[]{"Long", "employeeid", String.valueOf(lngEmployeeId)};
//        WebService.strParameters = strParameters;
//        WebService.METHOD_NAME = "getStudentAttendanceTemplateJson";
//        AsyncCallWS task = new AsyncCallWS();
//        task.execute();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // new intent to call an activity that you choose
        //Recycler View Menu
        Intent intent = new Intent(this, HomeScreen.class);
        //Grid View Menu
        //Intent intent = new Intent(this, HomePageGridViewLayout.class);
        startActivity(intent);
        // finish the activity picture
        this.finish();
    }

    private class AsyncCallWS extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog = new ProgressDialog(CanteenSelection.this);

        @Override
        protected void onPreExecute() {
            dialog.setMessage("Loading......");
            //show dialog
            dialog.show();
            Log.i(TAG, "onPreExecute");
        }

        @Override
        protected Void doInBackground(Void... params) {
            Log.i(TAG, "doInBackground");
            if (android.os.Debug.isDebuggerConnected())
                android.os.Debug.waitForDebugger();
              ResultString = WebService.invokeWS();
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            Log.i(TAG, "onPostExecute");
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
//            try {
                //JSONArray temp = new JSONArray(ResultString.toString());
//                for (int i = 0; i <= temp.length() - 1; i++) {
//                    JSONObject object = new JSONObject(temp.getJSONObject(i).toString());
//                    template_list.add(object.getString("canteenid") + "##" +object.getString("canteenname"));
//                }
//                if (template_list.size() == 0){
//                    Toast.makeText(CanteenSelection.this, "Response: No Data Found", Toast.LENGTH_LONG).show();
//                }
//                else {
//                    mRecyclerView = (RecyclerView) findViewById(R.id.rvTTTemplate); // Assigning the RecyclerView Object to the xml View
//                    mRecyclerView.setHasFixedSize(true);
//                    // Letting the system know that the list objects are of fixed size
//                    StudentAttendanceTemplateLVAdapter TVA = new StudentAttendanceTemplateLVAdapter(template_list, R.layout.studentattendancetemplatelistitem);
//                    mRecyclerView.setAdapter(TVA);
//                    mLayoutManager = new LinearLayoutManager(CanteenSelection.this);                 // Creating a layout Manager
//                    mRecyclerView.setLayoutManager(mLayoutManager);                 // Setting the layout Manager
//                }
//            } catch (Exception e) {
//                System.out.println(e.getMessage());
//            }
        }
    }

//    private class CustomAdapter extends BaseAdapter {
//        @Override
//        public int getCount() {
//            return Menu.length;
//        }
//        @Override
//        public Object getItem(int position) {
//            return null;
//        }
//        @Override
//        public long getItemId(int position) {
//            return 0;
//        }
//        @Override
//        public View getView(final int position, View convertView, ViewGroup parent) {
//            convertView=getLayoutInflater().inflate(R.layout.layout,null);
//            final TextView txtQuantity=(TextView) convertView.findViewById(R.id.txtquantity);
//            final TextView txtMenu=(TextView) convertView.findViewById(R.id.txtmenu);
//
//            txtMenu.setText(Menu[position]);
//            txtQuantity.setText(Integer.toString(Quantity[position]));
//            return convertView;
//        }
//    }

}