package com.example.staffportalshasun;

import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class LeaveApprovalLVAdapter extends RecyclerView.Adapter<LeaveApprovalLVAdapter.ViewHolder>{
    private static ArrayList<String> leavepending_list=new ArrayList<String>(500);
    private int itemLayout;

    public LeaveApprovalLVAdapter(ArrayList<String> leavepending_list, int itemLayout){
        this.leavepending_list = leavepending_list;
        this.itemLayout = itemLayout;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(itemLayout, parent, false);
        return new LeaveApprovalLVAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(LeaveApprovalLVAdapter.ViewHolder holder, int position){
        String item = leavepending_list.get(position);
        String[] strColumns = item.split("##");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            holder.textEmployeeName.setText(Html.fromHtml("<font color='#2e76b2'><b>Staff Name: </b></font>"+strColumns[1],Html.FROM_HTML_MODE_LEGACY));
            holder.textDepartment.setText(Html.fromHtml("<font color='#2e76b2'><b>Department: </b></font>"+strColumns[2],Html.FROM_HTML_MODE_LEGACY));
            holder.textDesignation.setText(Html.fromHtml("<font color='#2e76b2'><b>Designation: </b></font>"+strColumns[3],Html.FROM_HTML_MODE_LEGACY));
            holder.textLeaveType.setText(Html.fromHtml("<font color='#2e76b2'><b>Leave Type: </b></font>"+strColumns[4],Html.FROM_HTML_MODE_LEGACY));
            holder.textFromDate.setText(Html.fromHtml("<font color='#2e76b2'><b>From Date: </b></font>"+strColumns[5],Html.FROM_HTML_MODE_LEGACY));
            holder.textToDate.setText(Html.fromHtml("<font color='#2e76b2'><b>To Date: </b></font>"+strColumns[6],Html.FROM_HTML_MODE_LEGACY));
            holder.textSession.setText(Html.fromHtml("<font color='#2e76b2'><b>Session: </b></font>"+strColumns[7],Html.FROM_HTML_MODE_LEGACY));
            holder.textReason.setText(Html.fromHtml("<font color='#2e76b2'><b>Reason: </b></font>"+strColumns[8],Html.FROM_HTML_MODE_LEGACY));
            holder.textNoofDays.setText(Html.fromHtml("<font color='#2e76b2'><b>No of Days: </b></font>"+strColumns[9],Html.FROM_HTML_MODE_LEGACY));
        }
        else{
            holder.textEmployeeName.setText(Html.fromHtml("<font color='#2e76b2'><b>Staff Name: </b></font>"+strColumns[1]));
            holder.textDepartment.setText(Html.fromHtml("<font color='#2e76b2'><b>Department: </b></font>"+strColumns[2]));
            holder.textDesignation.setText(Html.fromHtml("<font color='#2e76b2'><b>Designation: </b></font>"+strColumns[3]));
            holder.textLeaveType.setText(Html.fromHtml("<font color='#2e76b2'><b>Leave Type: </b></font>"+strColumns[4]));
            holder.textFromDate.setText(Html.fromHtml("<font color='#2e76b2'><b>From Date: </b></font>"+strColumns[5]));
            holder.textToDate.setText(Html.fromHtml("<font color='#2e76b2'><b>To Date: </b></font>"+strColumns[6]));
            holder.textSession.setText(Html.fromHtml("<font color='#2e76b2'><b>Session: </b></font>"+strColumns[7]));
            holder.textReason.setText(Html.fromHtml("<font color='#2e76b2'><b>Reason: </b></font>"+strColumns[8]));
            holder.textNoofDays.setText(Html.fromHtml("<font color='#2e76b2'><b>No of Days: </b></font>"+strColumns[9]));
        }
    }

    @Override
    public int getItemCount() {
        return leavepending_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textEmployeeName;
        private TextView textDepartment;
        private TextView textDesignation;
        private TextView textLeaveType;
        private TextView textFromDate;
        private TextView textToDate;
        private TextView textSession;
        private TextView textReason;
        private TextView textNoofDays;
        private Button btnApprove;
        private Button btnReject;
        private long lngLeaveApplnId=0;

        public ViewHolder(View itemView){
            super(itemView);
            textEmployeeName = (TextView) itemView.findViewById(R.id.txtEmployeeName);
            textDepartment = (TextView) itemView.findViewById(R.id.txtDepartment);
            textDesignation = (TextView) itemView.findViewById(R.id.txtDesignation);
            textLeaveType = (TextView) itemView.findViewById(R.id.txtLeaveType);
            textFromDate = (TextView) itemView.findViewById(R.id.txtFromDate);
            textToDate = (TextView) itemView.findViewById(R.id.txtToDate);
            textSession = (TextView) itemView.findViewById(R.id.txtSession);
            textReason = (TextView) itemView.findViewById(R.id.txtReason);
            textNoofDays = (TextView) itemView.findViewById(R.id.txtNoofDays);
            btnApprove = (Button) itemView.findViewById(R.id.btnApprove);
            btnReject = (Button) itemView.findViewById(R.id.btnReject);

            //this.btnApprove.setOnClickListener();
            this.btnApprove.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                try {
                    String item = leavepending_list.get(getPosition());
                    String[] strColumns = item.split("##");
                    lngLeaveApplnId=Long.parseLong(strColumns[0]);
                    removeAt(getPosition());
                    ((LeaveApproval) v.getContext()).callLeaveApproveReject(lngLeaveApplnId,1);

                } catch (Exception e) {
                    // ignore
                }
                }
            });
            this.btnReject.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                try {
                    String item = leavepending_list.get(getPosition());
                    String[] strColumns = item.split("##");
                    lngLeaveApplnId=Long.parseLong(strColumns[0]);
                    removeAt(getPosition());
                    ((LeaveApproval) v.getContext()).callLeaveApproveReject(lngLeaveApplnId,9);
                } catch (Exception e) {
                    // ignore
                }
                }
            });
        }
    }

    public void removeAt(int position) {
        leavepending_list.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, leavepending_list.size());
    }
}
