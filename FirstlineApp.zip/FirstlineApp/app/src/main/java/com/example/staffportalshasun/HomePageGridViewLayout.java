package com.example.staffportalshasun;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.GridLayout;

import webservice.SqlliteController;

public class HomePageGridViewLayout extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridlayout_cardview_home_page);
        //Status Bar Color
        StatusColor.SetStatusColor(getWindow(), ContextCompat.getColor(this, R.color.colorblue));
        //final SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridViewmenu);
        setSingleEvent(gridLayout);
    }

    // we are setting onClickListener for each element
    private void setSingleEvent(GridLayout gridLayout) {
        for(int i = 0; i<gridLayout.getChildCount();i++){
            CardView cardView=(CardView)gridLayout.getChildAt(i);
            final int finalI= i;

            cardView.setOnClickListener(new View.OnClickListener() {
                SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
                SharedPreferences.Editor ed = loginsession.edit();
                @Override
                public void onClick(View view){
                    if (finalI == 0){
                        Intent intent = new Intent(HomePageGridViewLayout.this, PersonalDetails.class);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 1){
                        ed.putInt("menuflag", 1);
                        ed.commit();
                        Intent intent = new Intent(HomePageGridViewLayout.this, StudentAttendanceTemplate.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 2){
                        Intent intent = new Intent(HomePageGridViewLayout.this, LeaveStatus.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 3){
                        Intent intent = new Intent(HomePageGridViewLayout.this, LeaveEntry.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 4){
                        Intent intent = new Intent(HomePageGridViewLayout.this, LeaveApproval.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 5){
                        ed.putInt("menuflag", 2);
                        ed.commit();
                        Intent intent = new Intent(HomePageGridViewLayout.this, StudentAttendanceTemplate.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 6){
                        Intent intent = new Intent(HomePageGridViewLayout.this, InternalMarkEntryMain.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 7){
                        Intent intent = new Intent(HomePageGridViewLayout.this, StaffBiometricLog.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }

                    if (finalI == 9){
                        SharedPreferences myPrefs = getSharedPreferences("SessionLogin", MODE_PRIVATE);
                        SharedPreferences.Editor editor = myPrefs.edit();
                        editor.clear();
                        editor.commit();
                        SqlliteController sc = new SqlliteController(HomePageGridViewLayout.this);
                        sc.deleteLoginStaffDetails();
                        Intent intent = new Intent(HomePageGridViewLayout.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                    if (finalI == 10){
                        Intent intent = new Intent(HomePageGridViewLayout.this, NotificationForStudentsSubjectList.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                }
            });
        }
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }
}
