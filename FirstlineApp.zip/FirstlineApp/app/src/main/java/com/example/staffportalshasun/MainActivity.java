package com.example.staffportalshasun;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import webservice.EncryptDecrypt;
import webservice.SqlliteController;
import webservice.WebService;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button butLogin;
    EditText etUsername, etPassword;;
    String editTextUsername, editTextPassword;
    private static String strParameters[];
    private static String ResultString = "";
    SQLiteDatabase db;
    private String imeiNumber="";
    private String token="";
    TelephonyManager telephonyManager;
    SqlliteController controllerdb = new SqlliteController(this);
    EncryptDecrypt crypt = new EncryptDecrypt();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseMessaging.getInstance().subscribeToTopic("evarsity");

        FirebaseInstanceId.getInstance().getInstanceId()
        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                if (!task.isSuccessful()) {
                    Log.w(TAG, "getInstanceId failed", task.getException());
                    return;
                }
                // Get new Instance ID token
                token = task.getResult().getToken();
                // Log and toast
//                String msg = getString(R.string.msg_token_fmt, token);
//                Log.d(TAG, msg);
//                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
        deviceId();

        StatusColor.SetStatusColor(getWindow(), ContextCompat.getColor(this, R.color.colorblue));
        db = controllerdb.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT * FROM stafflogindetails ", null);
            if (cursor.moveToFirst()) {
                SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
                SharedPreferences.Editor ed = loginsession.edit();
                do {
                    ed.putLong("userid", cursor.getLong(cursor.getColumnIndex("employeeid")));
                    ed.putString("employeename", cursor.getString(cursor.getColumnIndex("employeename")));
                    ed.putString("department", cursor.getString(cursor.getColumnIndex("department")));
                    ed.putString("designation", cursor.getString(cursor.getColumnIndex("designation")));
//                    ed.putString("semester", cursor.getString(cursor.getColumnIndex("semester")));
//                    ed.putString("school", cursor.getString(cursor.getColumnIndex("school")));
//                    ed.putLong("courseid", cursor.getInt(cursor.getColumnIndex("courseid")));
                    ed.commit();
                } while (cursor.moveToNext());
                //Recycler View Menu
                Intent intent = new Intent(MainActivity.this, HomeScreen.class);
                //Grid View Menu
                //Intent intent = new Intent(MainActivity.this, HomePageGridViewLayout.class);
                startActivity(intent);
            } else {

            }
            cursor.close();
        }catch (Exception e){

        }
        if(CheckNetwork.isInternetAvailable(MainActivity.this)) {
            butLogin = (Button) findViewById(R.id.loginButton);
            butLogin.setOnClickListener(this);
            hideKeyboard();
        }
        else {
            Toast.makeText(MainActivity.this,"You dont have Internet connection", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onClick(View v){
        etUsername = (EditText) findViewById(R.id.usernameInput);
        etPassword = (EditText) findViewById(R.id.passwordInput);
        editTextUsername = etUsername.getText().toString().trim();
        editTextPassword = etPassword.getText().toString().trim();
        strParameters = new String[] { "String","userid","", "String","password", ""};
        SharedPreferences myPrefs = v.getContext().getSharedPreferences("SessionLogin", MODE_PRIVATE);
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.clear();
        editor.commit();
        SqlliteController sc = new SqlliteController(v.getContext());
        sc.deleteLoginStaffDetails();

        switch (v.getId()){
            case R.id.loginButton:
                if (! Utility.isNotNull(editTextUsername)){
                    etUsername.setError("username is required!");
                }
                if (! Utility.isNotNull(editTextPassword)){
                    etPassword.setError("password is required!");
                }
                deviceId();
                if (Utility.isNotNull(editTextPassword) && Utility.isNotNull(editTextUsername)) {
//                    String strData = editTextUsername + "#!#" + editTextPassword + " #!#" + imeiNumber + "#!#" + token;
//                    strData = crypt.getEncryptedData(strData);
                    //strParameters = new String[]{"String", "data", strData};
                    strParameters = new String[]{"String", "userid", editTextUsername, "String", "password", editTextPassword,
                                                 "String", "deviceid", imeiNumber, "String", "acesstoken", token};
                    new Thread(new Runnable(){
                        public void run() {
                        WebService.strParameters = strParameters;
                        WebService.METHOD_NAME = "authenticateLoginUserJson";  //"authenticateLoginUserJsonEncrypted";
                        AsyncCallWS task = new AsyncCallWS();
                        task.execute();
                        }
                    }).start();
                }
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }

    private void deviceId(){
        try {
            telephonyManager = (TelephonyManager) getSystemService(this.TELEPHONY_SERVICE);
//            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 101);
//                return;
//            } else {
                imeiNumber = telephonyManager.getDeviceId();
//                Log.d(TAG, imeiNumber);
//                Toast.makeText(MainActivity.this, imeiNumber, Toast.LENGTH_LONG).show();
//            }
        }catch(SecurityException e){
            imeiNumber = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode) {
            case 101:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 101);
                        return;
                    }
                    imeiNumber = telephonyManager.getDeviceId();
//                    Log.d(TAG, imeiNumber);
//                    Toast.makeText(MainActivity.this,imeiNumber,Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this,"Without permission we check",Toast.LENGTH_LONG).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void hideKeyboard(){
        View view = getCurrentFocus();
        if (view != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).
                    hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    private class AsyncCallWS extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute(){
            Log.i(TAG, "onPreExecute");
        }

        @Override
        protected Void doInBackground(Void... params) {
            Log.i(TAG, "doInBackground");
            if(android.os.Debug.isDebuggerConnected())
                android.os.Debug.waitForDebugger();
            ResultString = WebService.invokeWS();
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            Log.i(TAG, "onPostExecute");
            SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
            SharedPreferences.Editor ed = loginsession.edit();
            try{
               // String strResultString = crypt.getDecryptedData(ResultString.toString());
                JSONObject object = new JSONObject(ResultString.toString());
                if (!object.isNull("employeeid")){
                    ed.putLong("userid", object.getLong("employeeid"));
                    ed.putLong("officeid", object.getLong("officeid"));
//                    ed.putString("registerno", object.getString("registerno"));
                    ed.putString("employeename", object.getString("employeename"));
                    ed.putString("department", object.getString("department"));
                    ed.putString("designation", object.getString("designation"));
//                    ed.putString("school", object.getString("officename"));
//                    ed.putLong("courseid", object.getLong("courseid"));
                    Toast.makeText(MainActivity.this, "Successfully Logged In", Toast.LENGTH_LONG).show();
                    ed.commit();
                    SqlliteController sc = new SqlliteController(MainActivity.this);
                    sc.deleteLoginStaffDetails();
                    sc.insertLoginStaffDetails(object.getLong("employeeid"),object.getString("employeename"),
                            object.getString("department"),object.getString("designation"),object.getString("menuids"));
                    //Recycler View Menu
                    Intent intent = new Intent(MainActivity.this, HomeScreen.class);
                    //Grid View Menu
                    //Intent intent = new Intent(MainActivity.this, HomePageGridViewLayout.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this, "Login Failed: Not a Valid User Name / Password", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e){
                System.out.println("Error in Login Activity:"+e.getMessage());
            }
        }
    }
}
