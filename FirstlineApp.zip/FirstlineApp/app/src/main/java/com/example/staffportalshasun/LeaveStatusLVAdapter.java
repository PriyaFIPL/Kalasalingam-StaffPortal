package com.example.staffportalshasun;
import java.util.ArrayList;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class LeaveStatusLVAdapter extends RecyclerView.Adapter<LeaveStatusLVAdapter.ViewHolder> {
    private static ArrayList<String> leavestatus_list=new ArrayList<String>();
    private int itemLayout;

    public LeaveStatusLVAdapter(ArrayList<String> leavestatus_list, int itemLayout) {
        this.leavestatus_list = leavestatus_list;
        this.itemLayout = itemLayout;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(itemLayout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String item = leavestatus_list.get(position);
        String[] strColumns = item.split("##");
        String strApplnDateHTML="<font color='#2e76b2'><b>Application Date: </b></font>"+strColumns[0];
        String strLeaveTypeHTML="<font color='#2e76b2'><b>Leave Type: </b></font>"+strColumns[1];
        String strFromDateHTML="<font color='#2e76b2'><b>From Date: </b></font>"+strColumns[2];
        String strToDateHTML="<font color='#2e76b2'><b>To Date: </b></font>"+strColumns[3];
        String strSessionHTML="<font color='#2e76b2'><b>Session: </b></font>"+strColumns[4];
        String stReasonHTML="<font color='#2e76b2'><b>Reason: </b></font>"+strColumns[5];
        String strNoofDaysHTML="<font color='#2e76b2'><b>No of Days: </b></font>"+strColumns[6];
        String strLeaveStatusHTML="<font color='#2e76b2'><b>Leave Status: </b></font>"+strColumns[7];
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            holder.textApplnDate.setText(Html.fromHtml(strApplnDateHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textLeaveType.setText(Html.fromHtml(strLeaveTypeHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textFromDate.setText(Html.fromHtml(strFromDateHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textToDate.setText(Html.fromHtml(strToDateHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textSession.setText(Html.fromHtml(strSessionHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textReason.setText(Html.fromHtml(stReasonHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textNoofDays.setText(Html.fromHtml(strNoofDaysHTML,Html.FROM_HTML_MODE_LEGACY));
            holder.textLeaveStatus.setText(Html.fromHtml(strLeaveStatusHTML,Html.FROM_HTML_MODE_LEGACY));
        }
        else{
            holder.textApplnDate.setText(Html.fromHtml(strApplnDateHTML));
            holder.textLeaveType.setText(Html.fromHtml(strLeaveTypeHTML));
            holder.textFromDate.setText(Html.fromHtml(strFromDateHTML));
            holder.textToDate.setText(Html.fromHtml(strToDateHTML));
            holder.textSession.setText(Html.fromHtml(strSessionHTML));
            holder.textReason.setText(Html.fromHtml(stReasonHTML));
            holder.textNoofDays.setText(Html.fromHtml(strNoofDaysHTML));
            holder.textLeaveStatus.setText(Html.fromHtml(strLeaveStatusHTML));
        }
        if (!strColumns[7].trim().equals("Applied")){

            holder.btnCancel.setVisibility(View.INVISIBLE);
        }
        else{
            holder.btnCancel.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return leavestatus_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textApplnDate;
        private TextView textLeaveType;
        private TextView textFromDate;
        private TextView textToDate;
        private TextView textSession;
        private TextView textReason;
        private TextView textNoofDays;
        private TextView textLeaveStatus;
        private Button btnCancel;
        private long lngLeaveApplnId=0;

        public ViewHolder(View itemView){
            super(itemView);
            textApplnDate = (TextView) itemView.findViewById(R.id.txtApplnDate);
            textLeaveType = (TextView) itemView.findViewById(R.id.txtLeaveType);
            textFromDate = (TextView) itemView.findViewById(R.id.txtFromDate);
            textToDate = (TextView) itemView.findViewById(R.id.txtToDate);
            textSession = (TextView) itemView.findViewById(R.id.txtSession);
            textReason = (TextView) itemView.findViewById(R.id.txtReason);
            textNoofDays = (TextView) itemView.findViewById(R.id.txtNoofDays);
            textLeaveStatus = (TextView) itemView.findViewById(R.id.txtLeaveStatus);
            btnCancel = (Button) itemView.findViewById(R.id.btnCancel);

            this.btnCancel.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                try {
                    String item = leavestatus_list.get(getPosition());
                    String[] strColumns = item.split("##");
                    lngLeaveApplnId=Long.parseLong(strColumns[8]);
                    removeAt(getPosition());
                    ((LeaveStatus) v.getContext()).callLeaveCancel(lngLeaveApplnId);

                } catch (Exception e){
                    // ignore
                }
                }
            });
        }
    }

    public void removeAt(int position){
        leavestatus_list.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, leavestatus_list.size());
    }
}
