package com.example.staffportalshasun;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NotificationList extends AppCompatActivity implements View.OnClickListener {
    Button btnSent, btnReceived;
    TextView tvPageTitle;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notificationviewlist);
        tvPageTitle = (TextView) findViewById(R.id.pageTitle);
        tvPageTitle.setText("Notification List");

        Button btnBack=(Button) findViewById(R.id.button_back);
        Button btnRefresh=(Button) findViewById(R.id.button_refresh);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(NotificationList.this, HomeScreen.class);
                startActivity(intent);
            }
        });

        btnSent = (Button) findViewById(R.id.btnNotificationSent);
        btnReceived = (Button) findViewById(R.id.btnNotificationRece);
        btnSent.setOnClickListener(this);
        btnReceived.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btnNotificationSent:
                Intent intent = new Intent(NotificationList.this, NotificationView.class);
                intent.putExtra("sentreceivedflag","1");
                startActivity(intent);
                break;
            case R.id.btnNotificationRece:
                intent = new Intent(NotificationList.this, NotificationView.class);
                intent.putExtra("sentreceivedflag","2");
                startActivity(intent);
                break;
        }
    }
}
