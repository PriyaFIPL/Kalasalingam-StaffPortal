package com.example.staffportalshasun;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import webservice.SqlliteController;
import webservice.WebService;
import static android.content.ContentValues.TAG;
import static webservice.WebService.strParameters;

/**
 * Created by Firstline Infotech on 30-04-2019.
 */

public class PersonalDetails extends AppCompatActivity {
    private static String ResultString = "";
    private long lngEmployeeId=0;
    TextView tvEmployee, tvDob, tvDivision, tvAddress, tvDesignation,tvPageTitle, tvLastUpdated;
    TextView tvDoj, tvMobile, tvEmail;
    SQLiteDatabase db;
    SqlliteController controllerdb = new SqlliteController(this);

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personaldetails);
        StatusColor.SetStatusColor(getWindow(), ContextCompat.getColor(this, R.color.colorblue));
        tvPageTitle = (TextView) findViewById(R.id.pageTitle);
        tvPageTitle.setText("Profile");
        tvLastUpdated = (TextView) findViewById(R.id.txtLastUpdated);
        Button btnBack=(Button) findViewById(R.id.button_back);
        Button btnRefresh=(Button) findViewById(R.id.button_refresh);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
            //Recycler View Menu
            Intent intent = new Intent(PersonalDetails.this, HomeScreen.class);
            //Grid View Menu
            //Intent intent = new Intent(PersonalDetails.this, HomePageGridViewLayout.class);
            startActivity(intent);
            }
        });
        btnRefresh.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
            strParameters = new String[]{"Long", "employeeid", String.valueOf(lngEmployeeId)};
            WebService.strParameters = strParameters;
            WebService.METHOD_NAME = "employeePersonalDetailsJson";
            AsyncCallWS task = new AsyncCallWS();
            task.execute();
            }
        });
        final SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
        lngEmployeeId = loginsession.getLong("userid", 1);
//        strSchool = loginsession.getString("school", "");
        displayProfile();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // new intent to call an activity that you choose
        //Recycler View Menu
        Intent intent = new Intent(this, HomeScreen.class);
        //Grid View Menu
        //Intent intent = new Intent(this, HomePageGridViewLayout.class);
        startActivity(intent);
        // finish the activity picture
        this.finish();
    }

    private void displayProfile(){
        db = controllerdb.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT strftime('%d-%m-%Y %H:%M:%S', lastupdatedate) as lastupdated,* FROM profiledetails pf WHERE employeeid=" + lngEmployeeId, null);
            if (cursor.moveToFirst()){
                do {
                    tvLastUpdated.setText("Last Updated: "+cursor.getString(cursor.getColumnIndex("lastupdated")));
                    tvEmployee = (TextView) findViewById(R.id.txtEmployeeName);
                    tvEmployee.setText(cursor.getString(cursor.getColumnIndex("employeename")));

                    tvDivision = (TextView) findViewById(R.id.txtDivision);
                    tvDivision.setText(cursor.getString(cursor.getColumnIndex("division")));

                    tvDesignation = (TextView) findViewById(R.id.txtDesignation);
                    tvDesignation.setText(cursor.getString(cursor.getColumnIndex("designation")));

                    tvDob = (TextView) findViewById(R.id.txtDob);
                    tvDob.setText(cursor.getString(cursor.getColumnIndex("dob")));

                    tvDoj = (TextView) findViewById(R.id.txtDoj);
                    tvDoj.setText(cursor.getString(cursor.getColumnIndex("doj")));

                    tvMobile = (TextView) findViewById(R.id.txtMobile);
                    tvMobile.setText(cursor.getString(cursor.getColumnIndex("mobile")));

                    tvEmail = (TextView) findViewById(R.id.txtEmmail);
                    tvEmail.setText(cursor.getString(cursor.getColumnIndex("email")));

                    tvAddress = (TextView) findViewById(R.id.txtAddress);
                    tvAddress.setText(cursor.getString(cursor.getColumnIndex("address")));

                } while (cursor.moveToNext());
//                try {
//                    cursor = db.rawQuery("SELECT * FROM employeephoto pf WHERE employeeid=" + lngEmployeeId, null);
//                    if (cursor.moveToFirst()) {
//                        do {
//                            byte[] byteArrPhoto = cursor.getBlob(1); //Base64.decode(base64,Base64.DEFAULT);
//                            Bitmap bmp = BitmapFactory.decodeByteArray(byteArrPhoto, 0, byteArrPhoto.length);
//                            Bitmap croppedBmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getWidth());
//                            ImageView image = (ImageView) findViewById(R.id.imgEmployeePhoto);
//                            image.setImageBitmap(croppedBmp);
//
////                            ByteArrayInputStream imageStream = new ByteArrayInputStream(byteArrPhoto);
////                            Bitmap bmp = BitmapFactory.decodeStream(imageStream);
////                            Bitmap croppedBmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getWidth());
////                            ImageView image = (ImageView) findViewById(R.id.imgStudentPhoto);
////                            image.setImageBitmap(croppedBmp);
//
//                        } while (cursor.moveToNext());
//                    }
//                }catch(Exception e){}
            } else {
                strParameters = new String[]{"Long", "employeeid", String.valueOf(lngEmployeeId)};
                WebService.strParameters = strParameters;
                WebService.METHOD_NAME = "employeePersonalDetailsJson";
                AsyncCallWS task = new AsyncCallWS();
                task.execute();
            }
            cursor.close();
        }catch (Exception e){
            System.out.println(e.getMessage());
            strParameters = new String[]{"Long", "employeeid", String.valueOf(lngEmployeeId)};
            WebService.strParameters = strParameters;
            WebService.METHOD_NAME = "employeePersonalDetailsJson";
            AsyncCallWS task = new AsyncCallWS();
            task.execute();
        }
    }

//    public static byte[] getBytes(Bitmap bitmap) {
//        ByteArrayOutputStream stream = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
//        return stream.toByteArray();
//    }

    private class AsyncCallWS extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog = new ProgressDialog(PersonalDetails.this);
        @Override
        protected void onPreExecute() {
            dialog.setMessage("Loading......");
            //show dialog
            dialog.show();
            Log.i(TAG, "onPreExecute");
        }

        @Override
        protected Void doInBackground(Void... params) {
            Log.i(TAG, "doInBackground");
            if (android.os.Debug.isDebuggerConnected())
                android.os.Debug.waitForDebugger();
            ResultString = WebService.invokeWS();
            return null;
        }

        @Override
        protected void onPostExecute(Void result){
            Log.i(TAG, "onPostExecute");
            if(dialog != null && dialog.isShowing()){
                dialog.dismiss();
            }
            SharedPreferences loginsession = getApplicationContext().getSharedPreferences("SessionLogin", 0);
            SharedPreferences.Editor ed = loginsession.edit();
            try {
                SqlliteController sc = new SqlliteController(PersonalDetails.this);
                JSONObject object = new JSONObject(ResultString.toString());
                if (!object.isNull("Name")){
                    sc.insertProfileDetails(lngEmployeeId,object.getString("Name"),
                            object.getString("Division"),object.getString("Designation"),
                            object.getString("DOB"),object.getString("DOJ"),
                            object.getString("Mobile") , object.getString("Email"),
                            object.getString("Address"));
                    displayProfile();
                }
                else{
                    Toast.makeText(PersonalDetails.this, "No Personal Details Found", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}