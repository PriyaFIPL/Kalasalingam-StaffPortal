package webservice;

import android.app.Activity;

public class CryptService extends Activity {
    public CryptService() {
        super();
    }
}
